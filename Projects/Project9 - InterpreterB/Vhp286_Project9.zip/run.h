//
// Created by viraj on 5/3/2019.
//

#ifndef PROJECT9___INTERPRETERB_RUN_H
#define PROJECT9___INTERPRETERB_RUN_H
#include <vector>
#include "DataStructure.h"
#include "Expressions.cpp"

#endif //PROJECT9___INTERPRETERB_RUN_H
void run();
void exec(Expressions input[],Binary_ST* symbols);
void Parse(vector<Expressions>& parse, Binary_ST& symbols);