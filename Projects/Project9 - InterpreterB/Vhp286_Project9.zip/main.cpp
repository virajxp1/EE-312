//
// Created by viraj on 4/17/2019.
//
#include "Parse.h"
#include "run.h"
#include "DataStructure.h"
#include <string>
#include <iostream>
#include <vector>
#include "Expressions.cpp"



int main() {
    set_input("test7.blip");
    run();
}

