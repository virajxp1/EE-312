//
// Created by viraj on 4/17/2019.
//
#include "Parse.h"
#include "run.h"
#include "DataStructure.h"
#include <string>
#include <iostream>


int main() {
    set_input("test_grader.blip");
    run();
}
